!   FILE for FullProf Studio: generated automatically by FullProf 
!Title: LSQ refinement of LaMnO3       FIX xyz                                                                                                                              
SPACEG P n m a             
CELL     5.748192    7.694143    5.537546  90.0000  90.0000  90.0000  
box -0.15 1.15  -0.15 1.15 -0.15 1.15                                          
ATOM La1     La      -0.04865   0.25000   0.50808  
ATOM Mn1     Mn       0.00000   0.00000   0.00000  
ATOM O1      O        0.30685  -0.03846   0.22580  
ATOM O1_2    O        0.01182   0.25000   0.07451  
conn Mn O 0 2.3                                                                
poly Mn1                                                                       
