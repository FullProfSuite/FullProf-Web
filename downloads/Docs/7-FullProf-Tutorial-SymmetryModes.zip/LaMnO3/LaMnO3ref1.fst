!   FILE for FullProf Studio: generated automatically by FullProf 
!Title: LSQ refinement of LaMnO3       FIX xyz                                                                                                                              
SPACEG P n m a             
CELL     5.747933    7.693741    5.537291  90.0000  90.0000  90.0000  
box -0.15 1.15  -0.15 1.15 -0.15 1.15                                          
ATOM La1     LA     -0.04895  0.25000  0.50754  
ATOM Mn1     MN      0.00000  0.00000  0.00000  
ATOM O1      O       0.30686 -0.03851  0.22573  
ATOM O1_2    O       0.01266  0.25000  0.07459  
conn MN O 0 2.3                                                                
poly Mn1                                                                       
