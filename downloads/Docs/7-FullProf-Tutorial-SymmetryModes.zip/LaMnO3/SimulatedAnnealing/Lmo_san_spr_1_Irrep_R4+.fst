!Title: Structure corresponding to the single Irreducible representation:R4+
SPACEG P n m a                                                                  
CELL     5.74793    7.69374    5.53729    90.0000    90.0000    90.0000         
box -0.29 1.29  -0.31 1.31 -0.25 1.25
Atom La1    LA   0.00000     0.25000     0.50000  
Atom Mn1    MN   0.00000     0.00000     0.00000  
Atom O1     O    0.25000     0.00000     0.25000  
Atom O1_2   O    0.00000     0.25000     0.00000  
arrow_disp
{
LATTICE P
K   0.0   0.0   0.0
SYMM x,y,z                                                                      
MSYM u,v,w, 0.0                                                                 
SYMM x+1/2,-y+1/2,-z+1/2                                                        
MSYM u,-v,-w, 0.0                                                               
SYMM -x,y+1/2,-z                                                                
MSYM -u,v,-w, 0.0                                                               
SYMM -x+1/2,-y,z+1/2                                                            
MSYM -u,-v,w, 0.0                                                               
SYMM -x,-y,-z                                                                   
MSYM -u,-v,-w, 0.0                                                              
SYMM -x+1/2,y+1/2,z+1/2                                                         
MSYM -u,v,w, 0.0                                                                
SYMM x,-y+1/2,z                                                                 
MSYM u,-v,w, 0.0                                                                
SYMM x+1/2,y,-z+1/2                                                             
MSYM u,v,-w, 0.0                                                                
MATOM O1     O      0.25000   0.00000   0.25000   Scale   0.2851
SKP    1   1     0.00000   2.92366   0.00000  0.00000  0.00000  0.00000    0.00000
MATOM O1_2   O      0.00000   0.25000   0.00000   Scale   0.2851
SKP    1   1     0.00000   0.00000  -4.20846  0.00000  0.00000  0.00000    0.00000
}
