!   FILE for FullProf Studio: generated automatically by FullProf 
!Title: LSQ refinement of LaMnO3       FIX xyz                                                                                                                              
SPACEG P n m a             
CELL     5.747929    7.693738    5.537287  90.0000  90.0000  90.0000  
box -0.15 1.15  -0.15 1.15 -0.15 1.15                                          
ATOM La1     La      -0.04880   0.25000   0.50805  
ATOM Mn1     Mn       0.00000   0.00000   0.00000  
ATOM O1      O        0.30691  -0.03870   0.22546  
ATOM O1_2    O        0.01201   0.25000   0.07499  
