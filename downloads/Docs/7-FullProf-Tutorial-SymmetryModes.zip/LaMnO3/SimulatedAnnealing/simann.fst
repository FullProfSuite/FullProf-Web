!Title: Current Structure output by Simulated Annealing
SPACEG P n m a                                                                  
CELL      5.74793     7.69374     5.53729      90.000      90.000      90.000   
box -0.29 1.29  -0.31 1.31 -0.25 1.25
Atom La1    LA  -0.0487      0.25000     0.50779  
Atom Mn1    MN   0.00000     0.00000     0.00000  
Atom O1     O    0.30697    -0.0385      0.22565  
Atom O1_2   O    0.01183     0.25000     0.07473  
