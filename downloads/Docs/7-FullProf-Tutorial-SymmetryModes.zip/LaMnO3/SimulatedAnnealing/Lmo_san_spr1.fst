!   FILE for FullProf Studio: generated automatically by FullProf 
!Title: LSQ refinement of LaMnO3       FIX xyz                                                                                                                              
SPACEG P n m a             
CELL     5.747929    7.693738    5.537287  90.0000  90.0000  90.0000  
box -0.15 1.15  -0.15 1.15 -0.15 1.15                                          
ATOM La1     LA     -0.04941  0.25000  0.49253  
ATOM Mn1     MN      0.00000  0.00000  0.00000  
ATOM O1      O       0.19270  0.03859  0.27408  
ATOM O1_2    O       0.01213  0.25000 -0.07483  
