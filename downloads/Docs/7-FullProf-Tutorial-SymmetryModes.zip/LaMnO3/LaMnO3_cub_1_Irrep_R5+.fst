!Title: Structure corresponding to the single Irreducible representation:R5+
SPACEG P n m a                                                                  
CELL     5.74819    7.69414    5.53755    90.0000    90.0000    90.0000         
box -0.29 1.29  -0.31 1.31 -0.25 1.25
Atom La1    LA   0.00000     0.25000     0.50000  
Atom Mn1    MN   0.00000     0.00000     0.00000  
Atom O1     O    0.25000     0.00000     0.25000  
Atom O1_2   O    0.00000     0.25000     0.00000  
conn Mn O 0 2.3                                                                
poly Mn1                                                                       
arrow_disp
{
LATTICE P
K   0.0   0.0   0.0
SYMM x,y,z                                                                      
MSYM u,v,w, 0.0                                                                 
SYMM x+1/2,-y+1/2,-z+1/2                                                        
MSYM u,-v,-w, 0.0                                                               
SYMM -x,y+1/2,-z                                                                
MSYM -u,v,-w, 0.0                                                               
SYMM -x+1/2,-y,z+1/2                                                            
MSYM -u,-v,w, 0.0                                                               
SYMM -x,-y,-z                                                                   
MSYM -u,-v,-w, 0.0                                                              
SYMM -x+1/2,y+1/2,z+1/2                                                         
MSYM -u,v,w, 0.0                                                                
SYMM x,-y+1/2,z                                                                 
MSYM u,-v,w, 0.0                                                                
SYMM x+1/2,y,-z+1/2                                                             
MSYM u,v,-w, 0.0                                                                
MATOM La1    LA     0.00000   0.25000   0.50000   Scale   2.6832
SKP    1   1        0.00000   0.00000   0.44723  0.00000  0.00000  0.00000    0.00000
MATOM Mn1    MN     0.00000   0.00000   0.00000   Scale   2.6832
SKP    1   1        0.00000   0.00000   0.00000  0.00000  0.00000  0.00000    0.00000
MATOM O1     O      0.25000   0.00000   0.25000   Scale   2.6832
SKP    1   1        0.00000  -0.04629   0.00000  0.00000  0.00000  0.00000    0.00000
MATOM O1_2   O      0.00000   0.25000   0.00000   Scale   2.6832
SKP    1   1        0.00000   0.00000  -0.06663  0.00000  0.00000  0.00000    0.00000
}
