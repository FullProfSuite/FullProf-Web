  Tutorial on Symmetry Mode Crystallography with AMPLIMODES and FullProf
  ======================================================================

  In this directory we provide the a PDF document in which all the steps
  for working with symmtry modes using AMPLIMODES and FullProf are detailed.
  The file is called: FullProf-Tutorial-Symmetry-Modes.pdf

  Together with this document there are two directories corresponding to
  data and files for CaTiO3 and LaMnO3. The structure of the directories
  is in both cases the same, we will consider only the case of CaTiO3.

    CaTiO3   --- LeBailFit
             --- LSQ-Refinement
             --- Preparation
             --- SimulatedAnnealing
             --- Working

  In the CaTiO3 directory there is also the data file CaTiO3.dat, corresponding
  to a neutron powder diffraction pattern.
  In principle, if the user follows strictly what is written in the PDF document,
  there's no need to inspect the content of the different sub-directories. However,
  we give some input control files (PCR files) and other files to help the users
  with no experience with FullProf in case of problems.

  We suggest the following way of working:
    1: Copy the data file into the directory Working
    2: Read the PDF document and follow what is explained there, putting
       the created file in the Working directory.
    3: Copy and modify files within this directory for the different modes
       of working and clean up the directory, time to time, by moving the files
       to other directories created by the user.
    4: In case of problems, consult the files existing in some of the subdirectories
       of CaTiO3.

  Grenoble 20 May 2011
  JRC
