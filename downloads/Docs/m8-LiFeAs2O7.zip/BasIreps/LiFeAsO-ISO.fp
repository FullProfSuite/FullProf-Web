   -------------------------------
   Output of BasIREPS for FullProf
   -------------------------------
   The group of lines starting with the symbol of space groups and 
   finishing with the last keyword BASI, may be pasted into the PCR file
  
                 X       Y       Z           for site:  1
 -> Fe_1    :   0.0000  0.0000  0.0000  : (x,y,z)                                                     

 => Basis functions of Representation IRrep(  1) of dimension   2 contained  3 times in GAMMA
    Representation number    :  1 for Site:  1
    Number of basis functions:  3

 ----- Block-of-lines for PCR start just below this line
C -1                           <--Space group symbol for hkl generation
! Nsym   Cen  Laue Ireps N_Bas 
     1     1     1    -1     3
! Real(0)-Imaginary(1) indicator for Ci
  0  0  0
SYMM x,y,z                                                       
BASR   0  1  0   1  0  0   0  0  1
BASI   0  0  0   0  0  0   0  0  0
 ----- End-of-block of lines for PCR 
