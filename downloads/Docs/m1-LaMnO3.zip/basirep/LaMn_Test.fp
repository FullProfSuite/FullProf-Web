   -------------------------------
   Output of BasIREPS for FullProf
   -------------------------------
   The group of lines starting with the symbol of space groups and 
   finishing with the last keyword BASI, may be pasted into the PCR file
  
                 X       Y       Z           for site:  1
 -> Mn_1    :   0.5000  0.0000  0.0000  : (x,y,z) + (0,0,0)                                           
 -> Mn_2    :   0.5000  0.0000  0.5000  : (-x,-y,z+1/2) + (1,0,0)                                     
 -> Mn_3    :   0.0000  0.5000  0.0000  : (x+1/2,-y+1/2,-z) + (-1,0,0)                                
 -> Mn_4    :   0.0000  0.5000  0.5000  : (-x+1/2,y+1/2,-z+1/2) + (0,0,0)                             

 => Basis functions of Representation IRrep(  1) of dimension   2 contained  3 times in GAMMA
    Representation number    :  1 for Site:  1
    Number of basis functions:  6

 ----- Block-of-lines for PCR start just below this line
P -1                           <--Space group symbol for hkl generation
! Nsym   Cen  Laue Ireps N_Bas 
     4     1     1    -1     6
! Real(0)-Imaginary(1) indicator for Ci
  0  0  0  0  0  0
SYMM x,y,z                                                       
BASR   1  0  0   0  1  0   0  0  1  -1  0  0   0 -1  0   0  0 -1
BASI   0  0  0   0  0  0   0  0  0   0  0  0   0  0  0   0  0  0
SYMM -x+1,-y,z+1/2                                               
BASR   0  0  0   0  0  0   0  0  0   0  0  0   0  0  0   0  0  0
BASI  -1  0  0   0 -1  0   0  0  1  -1  0  0   0 -1  0   0  0  1
SYMM x-1/2,-y+1/2,-z                                             
BASR   0  0  0   0  0  0   0  0  0   0  0  0   0  0  0   0  0  0
BASI   1  0  0   0 -1  0   0  0 -1   1  0  0   0 -1  0   0  0 -1
SYMM -x+1/2,y+1/2,-z+1/2                                         
BASR  -1  0  0   0  1  0   0  0 -1   1  0  0   0 -1  0   0  0  1
BASI   0  0  0   0  0  0   0  0  0   0  0  0   0  0  0   0  0  0
 ----- End-of-block of lines for PCR 

 => Basis functions of Representation IRrep(  2) of dimension   2 contained  3 times in GAMMA
    Representation number    :  2 for Site:  1
    Number of basis functions:  6

 ----- Block-of-lines for PCR start just below this line
P -1                           <--Space group symbol for hkl generation
! Nsym   Cen  Laue Ireps N_Bas 
     4     1     1    -1     6
! Real(0)-Imaginary(1) indicator for Ci
  0  0  0  0  0  0
SYMM x,y,z                                                       
BASR   1  0  0   0  1  0   0  0  1  -1  0  0   0 -1  0   0  0 -1
BASI   0  0  0   0  0  0   0  0  0   0  0  0   0  0  0   0  0  0
SYMM -x+1,-y,z+1/2                                               
BASR   0  0  0   0  0  0   0  0  0   0  0  0   0  0  0   0  0  0
BASI  -1  0  0   0 -1  0   0  0  1  -1  0  0   0 -1  0   0  0  1
SYMM x-1/2,-y+1/2,-z                                             
BASR   0  0  0   0  0  0   0  0  0   0  0  0   0  0  0   0  0  0
BASI  -1  0  0   0  1  0   0  0  1  -1  0  0   0  1  0   0  0  1
SYMM -x+1/2,y+1/2,-z+1/2                                         
BASR   1  0  0   0 -1  0   0  0  1  -1  0  0   0  1  0   0  0 -1
BASI   0  0  0   0  0  0   0  0  0   0  0  0   0  0  0   0  0  0
 ----- End-of-block of lines for PCR 
