   -------------------------------
   Output of BasIREPS for FullProf
   -------------------------------
   The group of lines starting with the symbol of space groups and 
   finishing with the last keyword BASI, may be pasted into the PCR file
  
