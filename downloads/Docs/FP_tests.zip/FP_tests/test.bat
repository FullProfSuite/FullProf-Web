cd Ho2BaCuO5\TOF
fp2k  Ho2BaCuO5_1p5K_modes  Ho2BaCuO5_tof  Ho2BaCuO5_modes_tof
copy Ho2BaCuO5_modes_tof.log ..\..\.
cd ..\..\.
