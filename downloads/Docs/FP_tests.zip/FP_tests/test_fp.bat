del *.log
fp2k  Al2O3_Psett   Al2O3H_sim   Al2O3_Psett
fp2k  alum      alum      alum
fp2k  arg_si    arg_si    arg_si
fp2k  b8p       b8p       b8p
fp2k  c60       c60       c60
fp2k  c60s      c60       c60s
fp2k  c60a      c60       c60a
fp2k  Ca2MnO4_300k  Ca2MnO4_300k  Ca2MnO4_300k
fp2k  ce        ceo2      ce
fp2k  ce1       ceo2      ce1
fp2k  ce2       ceo2      ce2
fp2k  cecoal    cecoal    cecoal
fp2k  cecual    cecual    cecual
fp2k  cedif4rf  cedif4rf  cedif4rf
fp2k  ceo2_dl   ceo2_dl   ceo2_dl
fp2k  ceo2_pm   ceo2_dl   ceo2_pm
fp2k  ceo2mic   ceo2_dl   ceo2mic
fp2k  CeO2_PEARL  CeO2_PEARL  CeO2_PEARL
fp2k  cuf       cuf1k     cuf
fp2k  cuf1k     cuf1k     cuf1k
fp2k  dy        dy        dy
fp2k  dya       dy        dya
fp2k  dyb       dy        dyb
fp2k  dyc       dy        dyc
fp2k  dy2k      dy        dy2k
fp2k  DyFeO3_Irreps  DyFeO3_1p6K.xys DyFeO3_Irreps 
fp2k  DyFeO3_SSpace  DyFeO3_1p6K.xys DyFeO3_SSpace 
fp2k  DyMnGe_pm   dy      DyMnGe_pm
fp2k  DyMnGe_SuperSAnn   DyMnGe_pm1_cltr DyMnGe_SuperSAnn
fp2k  DyMnGe_SuperCryst  DyMnGe_pm1_cltr DyMnGe_SuperCryst
fp2k  DyMnGe_SuperSpace  dy  DyMnGe_SuperSpace
fp2k  DyMnGe_SuperSpaceSpher  dy  DyMnGe_SuperSpaceSpher
fp2k  gabriela  gabriela  gabriela
fp2k  hmt       hmt       hmt
fp2k  hob       hobb      hob
fp2k  hobb      hobb      hobb
fp2k  hobk      hobk      hobk
fp2k  hobk1     hobk      hobk1
fp2k  hobk2     hobk      hobk2
fp2k  hobk3     hobk      hobk3
fp2k  hobk_bas      hobk      hobk_bas
fp2k  Cc_2_c_15_90  hobk      hobk_monoc
fp2k  Ca_m_m_a  hobk      hobk_ortho
fp2k  hobsa     hobb      hobsa
cd Ho2BaCuO5\TOF
fp2k  Ho2BaCuO5_1p5K_modes  Ho2BaCuO5_tof  Ho2BaCuO5_1p5K_modes
copy Ho2BaCuO5_1p5K_modes.log ..\..\.
cd ..\CW\Sequential-Modes
copy HoBaCuO-LT_y0modes_init_save.pcr HoBaCuO-LT_y0modes.pcr
fp2k seq HoBaCuO-LT_y0modes multi_pattern     2   13 Y N N N Y  nowait  
copy HoBaCuO-LT_y0modes.log  seq_LT.log
del  HoBaCuO-LT_y0modes.log
copy HoBaCuO-HT_y0modes_init_save.pcr HoBaCuO-HT_y0modes.pcr
fp2k seq HoBaCuO-HT_y0modes multi_pattern     14   62 Y N N N Y  nowait  
copy HoBaCuO-HT_y0modes.log  seq_HT.log
del  HoBaCuO-HT_y0modes.log
copy *.log ..\..\..\.
cd ..\..\..\.
fp2k  hocu      hocu      hocu
fp2k  hpress    highpress hpress
fp2k  highpress highpress highpress
fp2k  k2na1p5   k2na1p5   k2na1p5
fp2k  la        la        la
fp2k  lab       la        lab
fp2k  lac       la        lac
fp2k  lamn_3t2  lamn_3t2  lamn_3t2
fp2k  lamn_san  lamn_san.int  lamn_san
fp2k  lamn_sann lamn_san  lamn_sann
fp2k  lamn_str  lamn_3t2  lamn_str
fp2k  lamn_pol  lamn_pol  lamn_pol
fp2k  layer     layer    layer
fp2k  LMO_Modes_Pbnm  lamn_3t2  LMO_Modes_Pbnm
fp2k  LMO_Modes_Pbnm_ani  lamn_3t2  LMO_Modes_Pbnm_ani
fp2k  LMO_Modes_Pbnm_Cheb  lamn_3t2  LMO_Modes_Pbnm_Cheb
fp2k  LMO_Modes_Pnma  lamn_3t2  LMO_Modes_Pnma
fp2k  maghem    maghem    maghem
fp2k  MgAl2O4s_Set1    MgAl2O4s   MgAl2O4s_Set1
fp2k  mixed     mixed     mixed
fp2k  monte     prnio     monte
fp2k  nabd4     nabd4     nabd4
fp2k  nac_3t2   nac_3t2   nac_3t2
fp2k  nac-osiris nac-osiris nac-osiris  
fp2k  ndni_htr  ndni_htr  ndni_htr
fp2k  ndni_lt7  ndni_ltr  ndni_lt7
fp2k  ndni_ltm  ndni_ltm  ndni_ltm
fp2k  ndni_ltn  ndni_ltr  ndni_ltn
fp2k  ndni_ltr  ndni_ltr  ndni_ltr
fp2k  p_p       p_p       p_p
fp2k  pb        pbso4     pb
fp2k  pb_ho     pb_ho     pb_ho
fp2k  pb_hob    pb_ho     pb_hob
fp2k  pb_san    pb_san    pb_san
fp2k  pb_sing   pbso4     pb_sing
fp2k  pbb       pbb       pbb
fp2k  pbho      pbho      pbho
fp2k  pbso      pbsox     pbso
fp2k  pbso4     pbso4     pbso4
fp2k  pbso4_cheb  pbso4   pbso4_cheb
fp2k  pbso4a    pbso4     pbso4a
fp2k  pbsom     pbsom     pbsom
fp2k  pbsox     pbsox     pbsox
fp2k  pdd       pdd       pdd
fp2k  piro-a    piro-a    piro-a
fp2k  prba10k   prbaco10k prba10k
fp2k  prbaco    prbaco    prbaco
fp2k  prca_2pat prca_2pat prca_2pat
fp2k  prca_p21nm prca_p21nm prca_p21nm 
fp2k  prca_std  prca_std  prca_std
fp2k  prnio     prnio     prnio
fp2k  rutana    rutana    rutana
fp2k  rutana_tch rutana   rutana_tch
fp2k  scn       scn       scn
fp2k  scor_rxn  scx       scor_rxn
fp2k  scx       scx       scx
fp2k  scxm      scx       scxm
fp2k  si3n4r    si3n4r    si3n4r
fp2k  sin_3t2   sin_3t2   sin_3t2
fp2k  tbba      tbbaco    tbba
fp2k  tbbaco    tbbaco    tbbaco
fp2k  time      timerev   time
fp2k  timerev   timerev   timerev
fp2k  urea      urea      urea
fp2k  ybacud1a  ybacud1a  ybacud1a
get_log
