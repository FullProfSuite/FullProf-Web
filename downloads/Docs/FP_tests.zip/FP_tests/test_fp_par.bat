del *.log
fp2k_par Al2O3_Psett   Al2O3H_sim   Al2O3_Psett
fp2k_par alum      alum      alum
fp2k_par arg_si    arg_si    arg_si
fp2k_par b8p       b8p       b8p
fp2k_par c60       c60       c60
fp2k_par c60s      c60       c60s
fp2k_par c60a      c60       c60a
fp2k_par Ca2MnO4_300k  Ca2MnO4_300k  Ca2MnO4_300k
fp2k_par ce        ceo2      ce
fp2k_par ce1       ceo2      ce1
fp2k_par ce2       ceo2      ce2
fp2k_par cecoal    cecoal    cecoal
fp2k_par cecual    cecual    cecual
fp2k_par cedif4rf  cedif4rf  cedif4rf
fp2k_par ceo2_dl   ceo2_dl   ceo2_dl
fp2k_par ceo2_pm   ceo2_dl   ceo2_pm
fp2k_par ceo2mic   ceo2_dl   ceo2mic
fp2k_par CeO2_PEARL  CeO2_PEARL  CeO2_PEARL
fp2k_par cuf       cuf1k     cuf
fp2k_par cuf1k     cuf1k     cuf1k
fp2k_par dy        dy        dy
fp2k_par dya       dy        dya
fp2k_par dyb       dy        dyb
fp2k_par dyc       dy        dyc
fp2k_par dy2k      dy        dy2k
fp2k_par DyFeO3_Irreps  DyFeO3_1p6K.xys DyFeO3_Irreps 
fp2k_par DyFeO3_SSpace  DyFeO3_1p6K.xys DyFeO3_SSpace 
fp2k_par DyMnGe_pm   dy      DyMnGe_pm
fp2k_par DyMnGe_SuperSAnn   DyMnGe_pm1_cltr DyMnGe_SuperSAnn
fp2k_par DyMnGe_SuperCryst  DyMnGe_pm1_cltr DyMnGe_SuperCryst
fp2k_par DyMnGe_SuperSpace  dy  DyMnGe_SuperSpace
fp2k_par DyMnGe_SuperSpaceSpher  dy  DyMnGe_SuperSpaceSpher
fp2k_par gabriela  gabriela  gabriela
fp2k_par hmt       hmt       hmt
fp2k_par hob       hobb      hob
fp2k_par hobb      hobb      hobb
fp2k_par hobk      hobk      hobk
fp2k_par hobk1     hobk      hobk1
fp2k_par hobk2     hobk      hobk2
fp2k_par hobk3     hobk      hobk3
fp2k_par hobk_bas      hobk      hobk_bas
fp2k_par Cc_2_c_15_90  hobk      hobk_monoc
fp2k_par Ca_m_m_a  hobk      hobk_ortho
fp2k_par hobsa     hobb      hobsa
cd Ho2BaCuO5\TOF
fp2k_par Ho2BaCuO5_1p5K_modes  Ho2BaCuO5_tof  Ho2BaCuO5_1p5K_modes
copy Ho2BaCuO5_1p5K_modes.log ..\..\.
cd ..\CW\Sequential-Modes
copy HoBaCuO-LT_y0modes_init_save.pcr HoBaCuO-LT_y0modes.pcr
fp2k_par seq HoBaCuO-LT_y0modes multi_pattern     2   13 Y N N N Y  nowait  
copy HoBaCuO-LT_y0modes.log  seq_LT.log
del  HoBaCuO-LT_y0modes.log
copy HoBaCuO-HT_y0modes_init_save.pcr HoBaCuO-HT_y0modes.pcr
fp2k_par seq HoBaCuO-HT_y0modes multi_pattern     14   62 Y N N N Y  nowait  
copy HoBaCuO-HT_y0modes.log  seq_HT.log
del  HoBaCuO-HT_y0modes.log
copy *.log ..\..\..\.
cd ..\..\..\.
fp2k_par hocu      hocu      hocu
fp2k_par hpress    highpress hpress
fp2k_par highpress highpress highpress
fp2k_par k2na1p5   k2na1p5   k2na1p5
fp2k_par la        la        la
fp2k_par lab       la        lab
fp2k_par lac       la        lac
fp2k_par lamn_3t2  lamn_3t2  lamn_3t2
fp2k_par lamn_san  lamn_san.int  lamn_san
fp2k_par lamn_sann lamn_san  lamn_sann
fp2k_par lamn_str  lamn_3t2  lamn_str
fp2k_par lamn_pol  lamn_pol  lamn_pol
fp2k_par lamn_pol_size lamn_pol lamn_pol_size
fp2k_par lamn_pol_str  lamn_pol lamn_pol_str
fp2k_par layer     layer    layer
fp2k_par LMO_Modes_Pbnm  lamn_3t2  LMO_Modes_Pbnm
fp2k_par LMO_Modes_Pbnm_ani  lamn_3t2  LMO_Modes_Pbnm_ani
fp2k_par LMO_Modes_Pbnm_Cheb  lamn_3t2  LMO_Modes_Pbnm_Cheb
fp2k_par LMO_Modes_Pnma  lamn_3t2  LMO_Modes_Pnma
fp2k_par maghem    maghem    maghem
fp2k_par MgAl2O4s_Set1    MgAl2O4s   MgAl2O4s_Set1
fp2k_par mixed     mixed     mixed
fp2k_par monte     prnio     monte
fp2k_par nabd4     nabd4     nabd4
fp2k_par nac_3t2   nac_3t2   nac_3t2
fp2k_par nac-osiris nac-osiris nac-osiris  
fp2k_par ndni_htr  ndni_htr  ndni_htr
fp2k_par ndni_lt7  ndni_ltr  ndni_lt7
fp2k_par ndni_ltm  ndni_ltm  ndni_ltm
fp2k_par ndni_ltn  ndni_ltr  ndni_ltn
fp2k_par ndni_ltr  ndni_ltr  ndni_ltr
fp2k_par p_p       p_p       p_p
fp2k_par pb        pbso4     pb
fp2k_par pb_ho     pb_ho     pb_ho
fp2k_par pb_hob    pb_ho     pb_hob
fp2k_par pb_san    pb_san    pb_san
fp2k_par pb_sing   pbso4     pb_sing
fp2k_par pbb       pbb       pbb
fp2k_par pbho      pbho      pbho
fp2k_par pbso      pbsox     pbso
fp2k_par pbso4     pbso4     pbso4
fp2k_par pbso4_cheb  pbso4   pbso4_cheb
fp2k_par pbso4a    pbso4     pbso4a
fp2k_par pbsom     pbsom     pbsom
fp2k_par pbsox     pbsox     pbsox
fp2k_par pdd       pdd       pdd
fp2k_par piro-a    piro-a    piro-a
fp2k_par prba10k   prbaco10k prba10k
fp2k_par prbaco    prbaco    prbaco
fp2k_par prca_2pat prca_2pat prca_2pat
fp2k_par prca_p21nm prca_p21nm prca_p21nm 
fp2k_par prca_std  prca_std  prca_std
fp2k_par prnio     prnio     prnio
fp2k_par rutana    rutana    rutana
fp2k_par rutana_tch rutana   rutana_tch
fp2k_par scn       scn       scn
fp2k_par scor_rxn  scx       scor_rxn
fp2k_par scx       scx       scx
fp2k_par scxm      scx       scxm
fp2k_par si3n4r    si3n4r    si3n4r
fp2k_par sin_3t2   sin_3t2   sin_3t2
fp2k_par tbba      tbbaco    tbba
fp2k_par tbbaco    tbbaco    tbbaco
fp2k_par time      timerev   time
fp2k_par timerev   timerev   timerev
fp2k_par urea      urea      urea
fp2k_par ybacud1a  ybacud1a  ybacud1a
get_log
