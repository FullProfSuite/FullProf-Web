TITLE Naphtalene
INPFIL napht-5k.hkl
OUTFIL nap
CELL     8.097201    5.943099    8.619699     90.0000    124.4200     90.0000
SPGR P 21/a
WAVE      0.83970
HKL_T    0
SCALE    1.000    
