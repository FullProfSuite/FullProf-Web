copy HoBaCuO-LT_y0modes_init_save.pcr HoBaCuO-LT_y0modes.pcr
fp2k seq HoBaCuO-LT_y0modes multi_pattern     2   13 Y N N N Y nowait +OUT 
copy HoBaCuO-LT_y0modes.log  seq_LT.log
del  HoBaCuO-LT_y0modes.log
copy HoBaCuO-HT_y0modes_init_save.pcr HoBaCuO-HT_y0modes.pcr
fp2k seq HoBaCuO-HT_y0modes multi_pattern     14   62 Y N N N Y nowait +OUT 
copy HoBaCuO-HT_y0modes.log  seq_HT.log