!   FILE for FullProf Studio: generated automatically by FullProf 
!Title: Nuclear and Magnetic Structure of: 3_P3    mxmymz VARY xyz
!Symmetry Operators of the Shubnikov Group: P3
SYMM  x,y,z
SYMM  -y,x-y,z
SYMM  -x+y,-x,z
CELL    10.081202   10.081202    6.267200  90.0000  90.0000 120.0000  
BOX   -0.15  1.15   -0.15  1.15    -0.15  1.15 
ATOM Mn1_1   Mn       0.33333   0.66667   0.48689  
ATOM Mn1_2   Mn       0.66667   0.33333   0.57690  
ATOM S1_1    S        0.67132   0.54353   1.08698  
ATOM S1_2    S        0.32038   0.44659   0.43312  
ATOM Na1     Na       0.00000   0.00000 521.29193  
ATOM Na2     Na       0.00000   0.00000 757.02472  
ATOM O1_1    O        0.80733   0.98359   0.78660  
ATOM O1_2    O        0.18720   0.01626   0.28918  
ATOM N1_1    N        0.50878   0.65182   0.65473  
ATOM N1_2    N        0.49024   0.34207   0.38750  
ATOM C1_1    C        0.58021   0.60331   0.73521  
ATOM C1_2    C        0.41373   0.39538   0.29269  
ATOM H1_1    H        0.70902   0.91024   0.72678  
ATOM H1_2    H        0.29021   0.10331   0.26091  
ATOM H2_1    H        0.82365   0.08160   0.76961  
ATOM H2_2    H        0.21268   0.93372   0.26679  
 
{
LATTICE  P
K     0.00000   0.00000   0.00000
SYMM  x,y,z
MSYM  u,v,w,0.0
SYMM  -y,x-y,z
MSYM  -v,u-v,w,0.0
SYMM  -x+y,-x,z
MSYM  -u+v,-u,w,0.0
MATOM Mn1_1   Mn       0.33333   0.66667   0.48689  SCALE 1.0 GROUP 
SKP           1  1   0.00000   0.00000   4.00000     0.00000   0.00000   0.00000    0.00000  
MATOM Mn1_2   Mn       0.66667   0.33333   0.57690  SCALE 1.0 GROUP 
SKP           1  1   0.00000   0.00000   3.90000     0.00000   0.00000   0.00000    0.00000  
}
