TITLE 
INPFIL C:\users_ILL\ejemplo_multiphase\work\2K\datared\mn_2K_all_abscan.hkl
OUTFIL 2K_-a-bc
CELL    10.038400   10.038400   10.038400     90.0000     90.0000    120.0000
SPGR P 3
WAVE      1.45567
HKL_T    0
TRANSF      -1.0000      0.0000      0.0000      0.0000     -1.0000      0.0000      0.0000      0.0000      1.0000
SCALE    1.000    
