!   FILE for FullProf Studio: generated automatically by FullProf 
!Title: data_NaMn_tayiye_100K_ag_a  VARY xyz b                                                                                                                              
SPACEG P -3                
CELL    10.081202   10.081202    6.267200  90.0000  90.0000 120.0000   DISPLAY MULTIPLE
BOX   -0.15  1.15   -0.15  1.15    -0.15  1.15 
ATOM Mn1     Mn       0.33333   0.66667   0.45663  
ATOM S1      S        0.67757   0.53559   0.83691  
ATOM Na1     Na       1.00000   1.00000   1.00000  
ATOM Na2     Na       1.00000   1.00000   0.50000  
ATOM O1      O        0.81109   0.98057   0.74319  
ATOM N1      N        0.51068   0.65501   0.63296  
ATOM C1      C        0.58002   0.60457   0.71718  
ATOM H1      H        0.70821   0.89930   0.74259  
ATOM H2      H        0.80525   1.07320   0.75616  
