TITLE 
INPFIL C:\users_ILL\ejemplo_multiphase\work\25K\mn_25K_abscan.hkl
OUTFIL 25K
CELL    10.038400   10.038400   10.038400     90.0000     90.0000    120.0000
SPGR P -3
WAVE      1.45567
HKL_T    0
SCALE    1.000    
