!   FILE for FullProf Studio: generated automatically by FullProf 
!Title: Nuclear and Magnetic Structure of: bcs_file_21736   VARY mxmymz
!Symmetry Operators of the Shubnikov Group: C_c2/c
SYMM  x,y,z
SYMM  -x,y,-z
SYMM  -x,-y,-z
SYMM  x,-y,z
SYMM  x+1/2,y,z+1/2
SYMM  -x+1/2,y,-z+1/2
SYMM  -x+1/2,-y,-z+1/2
SYMM  x+1/2,-y,z+1/2
SYMM  x+1/4,y+1/2,z+3/4
SYMM  -x+1/4,y+1/2,-z+3/4
SYMM  -x+1/4,-y+1/2,-z+3/4
SYMM  x+1/4,-y+1/2,z+3/4
SYMM  x+3/4,y+1/2,z+1/4
SYMM  -x+3/4,y+1/2,-z+1/4
SYMM  -x+3/4,-y+1/2,-z+1/4
SYMM  x+3/4,-y+1/2,z+1/4
SYMM  x,y,z+1/2
SYMM  -x,y,-z+1/2
SYMM  -x,-y,-z+1/2
SYMM  x,-y,z+1/2
SYMM  x+1/2,y,z
SYMM  -x+1/2,y,-z
SYMM  -x+1/2,-y,-z
SYMM  x+1/2,-y,z
SYMM  x+1/4,y+1/2,z+1/4
SYMM  -x+1/4,y+1/2,-z+1/4
SYMM  -x+1/4,-y+1/2,-z+1/4
SYMM  x+1/4,-y+1/2,z+1/4
SYMM  x+3/4,y+1/2,z+3/4
SYMM  -x+3/4,y+1/2,-z+3/4
SYMM  -x+3/4,-y+1/2,-z+3/4
SYMM  x+3/4,-y+1/2,z+3/4
CELL     7.509100    5.731900   22.543001  90.0000  90.0000  90.0000  
BOX   -0.15  1.15   -0.15  1.15    -0.15  1.15 
ATOM Ho1     Ho       0.25000   0.00000   0.10125  
ATOM Ba1     Ba       0.25000   0.50000   0.00000  
ATOM Ni1     Ni       0.00000   0.00000   0.00000  
ATOM O1      O        0.00000   0.24140   0.07475  
ATOM O2      O        0.00000   0.50000   0.25000  
 
{
LATTICE  P
K     0.00000   0.00000   0.00000
SYMM  x,y,z
MSYM  u,v,w,0.0
SYMM  -x,y,-z
MSYM  u,-v,w,0.0
SYMM  -x,-y,-z
MSYM  u,v,w,0.0
SYMM  x,-y,z
MSYM  u,-v,w,0.0
SYMM  x+1/2,y,z+1/2
MSYM  u,v,w,0.0
SYMM  -x+1/2,y,-z+1/2
MSYM  u,-v,w,0.0
SYMM  -x+1/2,-y,-z+1/2
MSYM  u,v,w,0.0
SYMM  x+1/2,-y,z+1/2
MSYM  u,-v,w,0.0
SYMM  x+1/4,y+1/2,z+3/4
MSYM  u,v,w,0.0
SYMM  -x+1/4,y+1/2,-z+3/4
MSYM  u,-v,w,0.0
SYMM  -x+1/4,-y+1/2,-z+3/4
MSYM  u,v,w,0.0
SYMM  x+1/4,-y+1/2,z+3/4
MSYM  u,-v,w,0.0
SYMM  x+3/4,y+1/2,z+1/4
MSYM  u,v,w,0.0
SYMM  -x+3/4,y+1/2,-z+1/4
MSYM  u,-v,w,0.0
SYMM  -x+3/4,-y+1/2,-z+1/4
MSYM  u,v,w,0.0
SYMM  x+3/4,-y+1/2,z+1/4
MSYM  u,-v,w,0.0
SYMM  x,y,z+1/2
MSYM  -u,-v,-w,0.0
SYMM  -x,y,-z+1/2
MSYM  -u,v,-w,0.0
SYMM  -x,-y,-z+1/2
MSYM  -u,-v,-w,0.0
SYMM  x,-y,z+1/2
MSYM  -u,v,-w,0.0
SYMM  x+1/2,y,z
MSYM  -u,-v,-w,0.0
SYMM  -x+1/2,y,-z
MSYM  -u,v,-w,0.0
SYMM  -x+1/2,-y,-z
MSYM  -u,-v,-w,0.0
SYMM  x+1/2,-y,z
MSYM  -u,v,-w,0.0
SYMM  x+1/4,y+1/2,z+1/4
MSYM  -u,-v,-w,0.0
SYMM  -x+1/4,y+1/2,-z+1/4
MSYM  -u,v,-w,0.0
SYMM  -x+1/4,-y+1/2,-z+1/4
MSYM  -u,-v,-w,0.0
SYMM  x+1/4,-y+1/2,z+1/4
MSYM  -u,v,-w,0.0
SYMM  x+3/4,y+1/2,z+3/4
MSYM  -u,-v,-w,0.0
SYMM  -x+3/4,y+1/2,-z+3/4
MSYM  -u,v,-w,0.0
SYMM  -x+3/4,-y+1/2,-z+3/4
MSYM  -u,-v,-w,0.0
SYMM  x+3/4,-y+1/2,z+3/4
MSYM  -u,v,-w,0.0
MATOM Ho1     Ho       0.25000   0.00000   0.10125  SCALE 1.0 GROUP 
SKP           1  1   2.00000   0.00000   7.00000     0.00000   0.00000   0.00000    0.00000  
MATOM Ni1     Ni       0.00000   0.00000   0.00000  SCALE 1.0 GROUP 
SKP           1  1   0.50000   0.00000   1.00000     0.00000   0.00000   0.00000    0.00000  
}
