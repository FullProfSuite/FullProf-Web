!   FILE for FullProf Studio: generated automatically by FullProf 
!Title: LaMnO3 x=0.0 Nuclear at 24C D2B                                                                                                                                     
SPACEG P b n m             
CELL     5.540309    5.759989    7.690836  90.0000  90.0000  90.0000   DISPLAY MULTIPLE
BOX   -0.15  1.15   -0.15  1.15    -0.15  1.15 
ATOM Mn      Mn       0.50000   0.00000   0.00000  
ATOM La      La      -0.00752   0.04965   0.25000  
ATOM O1      O        0.07804   0.48604   0.25000  
ATOM O2      O        0.72487   0.30809   0.03890  
