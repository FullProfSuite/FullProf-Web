!   FILE for FullProf Studio: generated automatically by FullProf 
!Title: Magnetic phase  MDLIM 1 1.23                                                                                                                                        
SPACEG P 1
CELL     5.540309    5.759989    7.690836  90.0000  90.0000  90.0000   DISPLAY MULTIPLE
BOX   -0.15  1.15   -0.15  1.15    -0.15  1.15 
 
{
LATTICE P
K     0.00000   0.00000   0.00000
SYMM x,y,z
MSYM u,v,w,0.0
MATOM Mn1     Mn       0.50000   0.00000   0.00000  SCALE 1.0 GROUP 
SKP           1  1   0.00000   0.31960   0.00000     0.00000   0.00000   0.00000    0.00000  
MATOM Mn2     Mn       0.00000   0.50000   0.00000  SCALE 1.0 GROUP 
SKP           1  1   0.00000   0.31960   0.00000     0.00000   0.00000   0.00000    0.00000  
MATOM Mn3     Mn       0.00000   0.50000   0.50000  SCALE 1.0 GROUP 
SKP           1  1   0.00000  -0.31960   0.00000     0.00000   0.00000   0.00000    0.00000  
MATOM Mn4     Mn       0.50000   0.00000   0.50000  SCALE 1.0 GROUP 
SKP           1  1   0.00000  -0.31960   0.00000     0.00000   0.00000   0.00000    0.00000  
}
